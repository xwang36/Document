mvdata <- read.table("/Users/sky/desktop/pa.mvtheft.frst40.dat", header=TRUE,na.strings=".")

require("psych")

mvts <- mvdata$mvtheft
mvts

mvyear <- mvdata$year
mvyear

mvtsoth <- mvdata$mvtheft    
mvyear0 <- mvyear-1960

fit1oth <- lm(mvts~mvyear0)
summary(fit1oth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit1oth$fitted.values)
library("AICcmodavg")
AICc(fit1oth)

fit2oth <- lm(mvts~ mvyear0 + I(mvyear0^2))
summary(fit2oth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit2oth$fitted.values)

fit3oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3))
summary(fit3oth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit3oth$fitted.values)

fit4oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3)+  I(mvyear0^4))
summary(fit4oth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit4oth$fitted.values)

fit5oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3)+ 
 I(mvyear0^4) + I(mvyear0^5))
summary(fit5oth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit5oth$fitted.values)
AICc(fit5oth)

fit6oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3)+ 
 I(mvyear0^4) + I(mvyear0^5)+ I(mvyear0^6))
summary(fit6oth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit6oth$fitted.values)
AICc(fit6oth)

fit7oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3)+ 
 I(mvyear0^4) + I(mvyear0^5)+ I(mvyear0^6) + I(mvyear0^7))
summary(fit7oth)
plotvars <- as.data.frame(mvyear0,mvtsoth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit7oth$fitted.values)
AICc(fit7oth)

fit8oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3)+ 
 I(mvyear0^4) + I(mvyear0^5)+ I(mvyear0^6) + I(mvyear0^7)+ 
 I(mvyear0^8))
summary(fit8oth)
plotvars <- as.data.frame(mvyear0,mvtsoth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit8oth$fitted.values)
AICc(fit8oth)

fit9oth <- lm(mvts~ mvyear0 + I(mvyear0^2) + I(mvyear0^3)+ 
 I(mvyear0^4) + I(mvyear0^5)+ I(mvyear0^6) + I(mvyear0^7)+ 
 I(mvyear0^8) + I(mvyear0^9))
summary(fit9oth)
plotvars <- as.data.frame(mvyear0,mvtsoth)
plot(mvyear0,mvtsoth)
lines(mvyear0,fit9oth$fitted.values)
AICc(fit9oth)

plot(mvyear0,mvtsoth)
lines(mvyear0,fit9oth$fitted.values)
lines(mvyear0,fit7oth$fitted.values)



