nextregdat <- read.table("/Users/sky/desktop/nextreg.forR.dat", header=TRUE,na.strings=".")

id <- nextregdat$id
tenanx <- nextregdat$tenanx
depres <- nextregdat$depres
anghos <- nextregdat$anghos
vigact <- nextregdat$vigact
fatint <- nextregdat$fatint
conbew <- nextregdat$conbew
xhachfi <- nextregdat$xhachfi
xhachfe <- nextregdat$xhachfe
xhachfo <- nextregdat$xhachfo
posthing <- nextregdat$posthing

constant <- 1

regmodel1 <- lm(xhachfi ~ tenanx + depres + anghos + vigact + fatint + conbew)
summary(regmodel1)

regmodel1a <- lm(xhachfi ~ tenanx + depres + vigact + fatint + conbew)
summary(regmodel1a)

regmodel1b <- lm(xhachfi ~ tenanx + depres + vigact + conbew)
summary(regmodel1b)

regmodel1c <- lm(xhachfi ~ tenanx + vigact + conbew)
summary(regmodel1c)

regmodel1d <- lm(xhachfi ~ vigact + conbew)
summary(regmodel1d)

regmodel1e <- lm(xhachfi ~ conbew)
summary(regmodel1e)

X <- cbind(tenanx,depres,anghos,vigact,fatint,conbew)

library(corpcor)
cor2pcor(cov(X))




