require("faraway")

star

starreg1 <- lm(light ~ temp, data=star)
summary(starreg1)
plot(star$temp,star$light)
abline(starreg1)

plot (star$temp,star$light, xlab="log(Temperature", ylab="Light Intensity")
lm(star$light ~ star$temp)

starobj <- lm(star$light ~ star$temp)
lines(star$temp,starobj$fitted.values)
summary(starobj)

halfnorm(lm.influence(starreg1)$hat,ylab="Leverage")
cook <- cooks.distance(starreg1)
halfnorm(cook,4,ylab="Cook's distance")
dfFits <- dffits(starreg1)
halfnorm(dfFits,4,ylab="dffits")


star1 <- star[-34,]
with(star1, {
plot (temp,light, xlab="log(Temperature", ylab="Light Intensity")
lm(light ~ temp)
starobj <<- lm(light ~ temp)
lines(temp,starobj$fitted.values)
})
summary(starobj)
dfFits <- dffits(starobj)
halfnorm(dfFits,4,ylab="dffits")


star2 <- star1[-30,]
with(star2, {
plot (temp,light, xlab="log(Temperature", ylab="Light Intensity")
lm(light ~ temp)
starobj <<- lm(light ~ temp)
lines(temp,starobj$fitted.values)
})
summary(starobj)
dfFits <- dffits(starobj)
halfnorm(dfFits,4,ylab="dffits")

star3 <- star2[-20,]
with(star3, {
plot (temp,light, xlab="log(Temperature", ylab="Light Intensity")
lm(light ~ temp)
starobj <<- lm(light ~ temp)
lines(temp,starobj$fitted.values)
})
summary(starobj)
dfFits <- dffits(starobj)
halfnorm(dfFits,4,ylab="dffits")

star4 <- star3[-11,]
with(star4, {
plot (temp,light, xlab="log(Temperature", ylab="Light Intensity")
lm(light ~ temp)
starobj <<- lm(light ~ temp)
lines(temp,starobj$fitted.values)
})
summary(starobj)
dfFits <- dffits(starobj)
halfnorm(dfFits,4,ylab="dffits")

star5 <- star4[-7,]
star5
with(star5, {
plot (temp,light, xlab="log(Temperature", ylab="Light Intensity")
lm(light ~ temp)
starobj <<- lm(light ~ temp)
lines(temp,starobj$fitted.values)
})
summary(starobj)
dfFits <- dffits(starobj)
halfnorm(dfFits,4,ylab="dffits")

star6 <- star5[-8,]
star6
with(star6, {
plot (temp,light, xlab="log(Temperature", ylab="Light Intensity")
lm(light ~ temp)
starobj <<- lm(light ~ temp)
lines(temp,starobj$fitted.values)
})
summary(starobj)




