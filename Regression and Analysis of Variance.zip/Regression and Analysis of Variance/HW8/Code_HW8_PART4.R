anova1 <- read.table("/Users/sky/desktop/ANOVA1.with.header.dat", header=TRUE,na.strings=".")

xhtenanx <- anova1$xhtenanx
xhdepres <- anova1$xhdepres
gender <- anova1$gender
anger <- anova1$anger
fatigue <- anova1$fatigue

anger <- as.factor(anger)
fatigue <- as.factor(fatigue)

anovafac1a <- lm(xhdepres ~ anger)
summary(anovafac1a)
anova(anovafac1a) 

anger2 <- as.integer(anger)  
anger2 <- 4-anger2           
anger2 <- as.factor(anger2)      
anovafac1b <- lm(xhdepres ~ anger2)
anova(anovafac1b)
summary(anovafac1b)
TukeyHSD(aov(lm(xhdepres ~ anger2)))

anovafac1c <- lm(xhdepres ~ fatigue)
summary(anovafac1c)
anova(anovafac1c)

fatigue2 <- as.integer(fatigue)  
fatigue2 <- 4-fatigue2           
fatigue2 <- as.factor(fatigue2)      
anovafac1d <- lm(xhdepres ~ fatigue2)
anova(anovafac1d)
summary(anovafac1d)
TukeyHSD(aov(lm(xhdepres ~ fatigue2)))












