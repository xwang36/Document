nextregdat<-read.table("/Users/sky/desktop/nextreg.forR.dat", header=TRUE,na.strings=".")

id <- nextregdat$id
tenanx <- nextregdat$tenanx
depres <- nextregdat$depres
anghos <- nextregdat$anghos
vigact <- nextregdat$vigact
fatint <- nextregdat$fatint
conbew <- nextregdat$conbew
xhachfi <- nextregdat$xhachfi
xhachfe <- nextregdat$xhachfe
xhachfo <- nextregdat$xhachfo
posthing <- nextregdat$posthing

require("car")

regmodelseq1 <- lm(conbew ~ xhachfe )
summary(regmodelseq1)
regmodelseq2 <- lm(conbew ~  xhachfi)
summary(regmodelseq2)
regmodelseq3 <- lm(conbew ~  xhachfo)
summary(regmodelseq3)
regmodelseq4 <- lm(conbew ~ xhachfe)
summary(regmodelseq4)
regmodelseq5 <- lm(conbew ~ xhachfe + xhachfi)
summary(regmodelseq5)
regmodelseq6 <- lm(conbew ~ xhachfe + xhachfi + xhachfo)
summary(regmodelseq6)

# Type I and Type II
reg_fe_fi_fo <- lm(conbew ~ xhachfe + xhachfi + xhachfo)
summary(reg_fe_fi_fo)
anova(reg_fe_fi_fo)                       
Anova(lm(conbew ~ xhachfe + xhachfi + xhachfo), type=2) 