training2<-read.table("/Users/sky/desktop/TRAINING.SERIES2.Dat", header=TRUE,col.names=c("id","hrstrn","testscor"),na.strings=".") 

testscor <- training2$testscor
x <- training2$hrstrn
xcen <- x-mean(x)

ser1reg1 <-lm(testscor~x)
summary(ser1reg1)

ser1reg2 <- lm(testscor ~ I(x) + I(x^2))
summary(ser1reg2)

ser1reg3 <- lm(testscor ~ I(x) + I(x^2) + I(x^3) )
summary(ser1reg3) 

ser1reg4 <- lm(testscor ~ I(x) + I(x^2) + I(x^3) + I(x^4) )
summary(ser1reg4) 

ser1reg5 <- lm(testscor ~ I(x) + I(x^2) + I(x^3) + I(x^4) + I(x^5))
summary(ser1reg5) 

windows()
plot(x,ser1reg3$fitted.values)

windows()
plot(x,testscor)
lines(sort(x),ser1reg3$fitted.values[order(x)])

ser1creg1 <-lm(testscor~xcen)
summary(ser1creg1)

ser1creg2 <- lm(testscor ~ I(xcen) + I(xcen^2))
summary(ser1creg2)

ser1creg3 <- lm(testscor ~ I(xcen) + I(xcen^2) + I(xcen^3) )
summary(ser1creg3) 

ser1creg4 <- lm(testscor ~ I(xcen) + I(xcen^2) + I(xcen^3) + I(xcen^4) )
summary(ser1creg4) 

ser1creg5 <- lm(testscor ~ I(xcen) + I(xcen^2) + I(xcen^3) + I(xcen^4) + I(xcen^5))
summary(ser1creg5) 

windows()
plot(xcen,testscor)
lines(sort(xcen),ser1reg3$fitted.values[order(xcen)])