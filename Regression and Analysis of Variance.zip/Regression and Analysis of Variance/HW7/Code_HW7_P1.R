proficiencydat<-read.table("/Users/sky/desktop/proficiency.forR.dat", header=TRUE,na.strings=".")

proficiency_regression <- lm(proficiency_score ~ course_comp + retake, data=proficiencydat )
summary (proficiency_regression)

proficiency_i_regression <- lm(proficiency_score ~ course_comp + retake + (course_comp*retake), data=proficiencydat)
summary (proficiency_i_regression)

course_cat <- c(0,0,0,1)
retake_cat <- c(1,0,1,1)

yp_out_i <- 872.52 + course_cat*(-203.36) + retake_cat*(-169.24)

yp_out_i

yp_with_i<- 943.000000 + course_cat*(-414.80000) + retake_cat*(-380.68000) + course_cat*retake_cat*(422.88000)
 
yp_with_i
