# read in the data
hibbs <- read.table("e:/EDUC767 fall 2021/files for 092021/hibbs.dat", header=TRUE)

# check the data
head(hibbs)