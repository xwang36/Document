# here are the data in a comma separated value file
Bordeaux <- read.csv("e:/EDUC767 fall 2021/Bordeaux.csv", header=TRUE)
head(Bordeaux)  # check the file
names(Bordeaux) # find out the variable names

# set some graphing parameters
par(mfrow=c(1,2),oma = c(0, 0, 2, 0))
# plot the two subsets
plot(Bordeaux$ParkerPoints,Bordeaux$Price, xlab="Parker Points", 
   ylab="Price")
plot(Bordeaux$CoatesPoints,Bordeaux$Price, xlab="Coates Points", 
   ylab="")
mtext("Who is better?", outer=TRUE, cex=1.5)  # add a main title
