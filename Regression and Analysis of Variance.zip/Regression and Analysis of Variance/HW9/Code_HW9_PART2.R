anova1 <- read.table("/Users/sky/desktop/q2data.activity.121321.forR.dat", header=TRUE,na.strings=".")

gender <- anova1$gender
readgrp <- anova1$readgrp
mathscor <- anova1$mathscor

gender <- as.factor(gender)
readgrp <- as.factor(readgrp)

model_1 <- lm(mathscor ~ gender*readgrp)
summary(model_1)
anova(model_1)

options(contrasts = c("contr.sum","contr.poly"))
model_1 <- lm(mathscor ~ gender*readgrp)
summary(model_1)
drop1(model_1, .~., test="F")

aggregate(anova1$mathscor,list(anova1$readgrp),FUN=mean)
aggregate(anova1$mathscor,list(anova1$gender,anova1$readgrp),FUN=mean)

creadgrp1 <- c(0,0,-1,1)
creadgrp2 <- c(-1,-1,2,0)
creadgrp3 <- c(0,-1,1,0)


