anova1 <- read.table("/Users/sky/desktop/q1data.activity.121321.forR.dat", header=TRUE,na.strings=".")

agegrp <- anova1$agegrp
adjustgrp <- anova1$adjustgrp
satis <- anova1$satis

agegrp <- as.factor(agegrp)
adjustgrp <- as.factor(adjustgrp)

model_1 <- lm(satis ~ agegrp*adjustgrp)
summary(model_1)
anova(model_1)

options(contrasts = c("contr.sum","contr.poly"))
model_1 <- lm(satis ~ agegrp*adjustgrp)
summary(model_1)
drop1(model_1, .~., test="F")

aggregate(anova1$satis,list(anova1$adjustgrp),FUN=mean)
aggregate(anova1$satis,list(anova1$agegrp,anova1$adjustgrp),FUN=mean)

cadjustgrp1 <- c(-1,1,0,0)
cadjustgrp2 <- c(0,-1,1,0)
cadjustgrp3 <- c(0,0,-1,1)





