discrimdat<-read.table("/Users/sky/desktop/discrim2.forR.dat", header=TRUE,na.strings=".")
id <- discrimdat$id
love <-discrimdat$love
conf <- discrimdat$conf
amb <- discrimdat$amb
maint<- discrimdat$maint
tenanx <- discrimdat$tenanx
depres <- discrimdat$depres
anghos <- discrimdat$anghos
vigact <- discrimdat$vigact
fatint <- discrimdat$fatint
conbew <- discrimdat$conbew
achfi <- discrimdat$achfi
achfe <- discrimdat$achfe
achfo <- discrimdat$achfo
posthing <- discrimdat$posthing

require("car")
regmodelseq_1 <- lm(posthing ~ love + conf + amb + maint)
summary(regmodelseq_1)
regmodelseq_2 <- lm(posthing ~ love + conf + amb + maint + tenanx + depres + anghos + vigact + fatint + conbew)
summary(regmodelseq_2)
regmodelseq_3 <- lm(posthing ~ love + conf + amb + maint + tenanx + depres + anghos + vigact + fatint + conbew + achfi + achfe + achfo)
summary(regmodelseq_3)

anova(regmodelseq_1,regmodelseq_2,regmodelseq_3)

# backward stepwise
regmodel_4 <- lm(posthing ~ love + conf + amb + maint)
summary(regmodel_4)
step(regmodel_4, direction="backward")
regmodel_5 <- lm(posthing ~ tenanx + depres + anghos + vigact + fatint + conbew)
summary(regmodel_5)
step(regmodel_5, direction="backward")
regmodel_6 <- lm(posthing ~ achfi + achfe + achfo)
summary(regmodel_6)
step(regmodel_6, direction="backward")

regmodelseq_a <- lm(posthing ~ conf + amb + maint + depres + achfe + achfo )
summary(regmodelseq_a)

# forward stepwise regression
min.model = lm(posthing ~ 1)
summary(min.model)
fwd.model <- step(min.model, direction='forward', 
                  scope=(~ love + conf + amb + maint))
summary(fwd.model)
fwd.model$anova

min.model = lm(posthing ~ 1)
summary(min.model)
fwd.model <- step(min.model, direction='forward', 
                  scope=(~ tenanx + depres + anghos + vigact + fatint + conbew))
summary(fwd.model)
fwd.model$
  
min.model = lm(posthing ~ 1)
summary(min.model)
fwd.model <- step(min.model, direction='forward', 
                  scope=(~ achfi + achfe + achfo))
summary(fwd.model)
fwd.model$anova

regmodelseq_b <- lm(posthing ~ conf + amb + maint + depres + achfe + achfo )
summary(regmodelseq_b)
