###### Read in the data ######
indicatorDf <- read.table("/Users/sky/desktop/indicators.dat", header=TRUE)
indicatorDf

###### To create a new variable, region12 ######
region12 <- NULL
for (i in 1:18){
  if(indicatorDf$Region[i] == 1) region12[i] <- 1
  if(indicatorDf$Region[i] == 3) region12[i] <- 1
  if(indicatorDf$Region[i] == 2) region12[i] <- 2
  if(indicatorDf$Region[i] == 4) region12[i] <- 2
}
region12

###### To put Region and region12 into a matrix ######
regionmatrix <- cbind(region12,indicatorDf)
regionmatrix

###### Sort the subgroup region12 ######
regionmatrix[order(regionmatrix[,1]),]

###### Mean of the subgroups ######
mean_group1 <- mean(indicatorDf$LoanPaymentsOverdue[1:6])
mean_group1

mean_group2 <- mean(indicatorDf$LoanPaymentsOverdue[7:18])
mean_group2

mean_difference <- mean_group1-mean_group2
mean_difference

###### Plot region12 and LoanPaymentsOverdue ######
###### Yes, this intercept is useful and makes sense ######
###### That intercept is the mean difference ######
plot(region12, indicatorDf$LoanPaymentsOverdue, xlab="region12",
     ylab="LoanPaymentsOverdue", 
     main = "Prediction")  

indicator_reg <- lm(LoanPaymentsOverdue ~ region12, data=regionmatrix) 
indicator_reg
summary(indicator_reg)

abline(coef(indicator_reg))


