###### read in the data ###### 
clean <- read.table("/Users/sky/desktop/cleaning.dat", header=TRUE)
clean

###### To generate descriptive statistics for the variables Crews and Rooms ###### 
###### Yes, the distribution of Crews is skewed, which is 0.14; the distribution of Rooms is skewed, which is 0.27 ###### 
cleanmatrix <- cbind(clean$Crews,clean$Rooms)
cleanmatrix
require("psych")
describe(cleanmatrix)

######  To generate a boxplot and qqplot for Crews and Rooms ###### 
par(mfrow=c(1,3))
boxplot(clean$Crews )
hist(clean$Crews )
plot(density(clean$Crews))
qqnorm(clean$Crews,ylab="Crews")
qqline(clean$Crews)

par(mfrow=c(1,4))
boxplot(clean$Rooms)
hist(clean$Rooms)
plot(density(clean$Rooms))
qqnorm(clean$Rooms,ylab="Crews")
qqline(clean$Rooms)

######  Plot the variables of Crews and Rooms ###### 
plot(clean$Crews)
plot(clean$Rooms)

###### Run an unstandardized regression ###### 
###### Yes, the slope is significant and the slope is 3.7009 ###### 
###### The Adjusted R-square is 0.854, which is very large ###### 
plot(clean$Crews,clean$Rooms, xlab="Crews",
     ylab="Rooms", 
     main = "Prediction")  

clean_reg <- lm(Rooms ~ Crews, data=clean) 
clean_reg
summary(clean_reg)

abline(coef(clean_reg))   

###### To get the standardized regression ######
###### The standardized regression coefficient is 0.9257 ######
###### The relationship is that it will increase 0.9257 crew for each room increased ######
clean_scale_reg <- lm(scale(Rooms) ~ scale(Crews), data=clean)
clean_scale_reg
summary(clean_scale_reg)


###### Based on the regression equation, the predicted number of rooms that a crew of 10 is 38.8 ######
###### When 10 crews are working, the number of complete rooms could be from 36 to 38 ######

###### In conclusion, I think 10 crews will be enough based on the above analysis ######

