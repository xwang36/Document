# read in the data
hibbs <- read.table("/Users/sky/desktop/hibbs.dat", header=TRUE)

# get the regression statistics of hibbsReg
hibbsReg <- lm(vote ~ growth, data=hibbs) 
hibbsReg
summary(hibbsReg)

# I create a second data frame without 1952
hibbs2 <- hibbs[2:16,]   

# get the regression statistics of hibbs2Reg()
hibbs2Reg <- lm(vote ~ growth, data=hibbs2)  
hibbs2Reg
summary(hibbs2Reg)

# get the regression statistics of hibbs_scale
hibbs_scale <- lm(scale(vote) ~ scale(growth), data=hibbs)
hibbs_scale
summary(hibbs_scale)

# get the regression statistics of hibbs2_scale
hibbs2_scale <- lm(scale(vote) ~ scale(growth), data=hibbs2)
hibbs2_scale
summary(hibbs2_scale)



# Yes, the unstandardized regression line changes with and out the 1952 data point.  

# Yes, the standardized regression coefficients changes with and out the 1952 data point. 
# Meanwhile, the standardized regression coefficients also changes from the unstandrdized regression line to the standardized regression line. 

# The R-square changes with and out the 1952 data point.
# However, the R-square does not change from the unstandardized regression line to the standardized regression line.

# The significance level of the regression slope changes with and out the 1952 data point.
# However, the significance level of the regression slope does not change from the unstandardized regression line to the standardized regression line. 



#calculate the correlation coefficient
cor(hibbs$vote,hibbs$growth)
cor(hibbs2$vote,hibbs2$growth)

# For the standardlized model with 1952, the Estimate is 7.615e-01, which is equal to the correlation coefficient. 
# For the standardlized model without 1952, the Estimate is 8.547e-01 , which is equal to the correlation coefficient. 
# The correlation changes from 0.76 (with 1952) to 0.85 (without 1952)
