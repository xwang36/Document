setwd("e:/EDUC767 fall 2021")
mvdata <- read.table("pa.mvtheft.frst40.dat", header=TRUE, na.strings=".")

require("psych")

# fit polynomial

mvts <- mvdata$mvtheft
mvts
attributes(mvts)

mvyear <- mvdata$year
mvyear
attributes(mvyear)

# not a good idea to use 1960 as the initial point with polynomials
mvtsoth <- mvdata$mvtheft    # same variable
mvyear0 <- mvyear-1960

plot(mvyear0,mvtsoth)

fit1oth <- lm(mvts~mvyear0)
summary(fit1oth)

plot(mvyear0,mvtsoth)
lines(mvyear0,fit1oth$fitted.values)

# the next few functions are for your information
# you don't need them for the assignment
# we will discuss these in class

# draw histogram
hist(fit1oth$residuals)

# draw boxplot
boxplot(fit1oth$residuals)

# draw qqplot    # this is a quantile/quantile probability plot
qqnorm(fit1oth$residuals,ylab="fit1oth$residuals")    # plots the variable against an ideal normal
qqline(fit1oth$residuals)                 # draws the diagonal line

# Shapiro-Wilks test of normality - use n less than about 2000
shapiro.test(fit1oth$residuals)

# Kolmogorov-Smirnoff test of normality - use n greater than about 2000
ks.test(fit1oth$residuals,"pnorm")

# testing for serial correlation of the residuals
# time 2 predicted with time 1   
sercorr1oth1 <- lm(fit1oth$residuals[-1] ~ fit1oth$residuals[-length(fit1oth$residuals)]) 
summary(sercorr1oth1)

require("lmtest")
dwtest(lm(mvts~mvyear0))    # Durbin Watson test of autocorrelation

# the second order for your information
fit2oth <- lm(mvts~ mvyear0 + I(mvyear0^2))
summary(fit2oth)

plot(mvyear0,mvtsoth)
lines(mvyear0,fit2oth$fitted.values)

