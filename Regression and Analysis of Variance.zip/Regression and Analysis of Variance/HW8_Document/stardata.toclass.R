setwd("e:/EDUC767 fall 2021")
getwd()

# options(scipen = 999)  # turn off scientific notation
# options(scipen = 0) # turn back on
# get raw data set

require("faraway")

star

is.data.frame(star)

plot (star$temp,star$light, xlab="log(Temperature", ylab="Light Intensity")


