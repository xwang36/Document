setwd("e:/EDUC767 fall 2021/Activity for 121321")
anovaq3 <- read.table("q1data.activity.121321.forR.dat", header=TRUE, na.strings=".")
names(anovaq3)

# simplify names
agegrp <- anovaq3$agegrp
adjustgrp <- anovaq3$adjustgrp
satis <- anovaq3$satis

agegrp <- as.factor(agegrp)
adjustgrp <- as.factor(adjustgrp)

# with both variables
modelforq3 <- lm(satis ~ agegrp*adjustgrp)
summary(modelforq3)
#TYPE I SS
anova(modelforq3)
# Type III SS 
options(contrasts = c("contr.sum","contr.poly"))
modelforq3 <- lm(satis ~ agegrp*adjustgrp)
summary(modelforq3)
drop1(modelforq3, .~., test="F")

# followup constrasts
# add contrasts for main effects 
cadjustgrp1 <- c(-1,1,0,0)
cadjustgrp2 <- c(0,-1,-1,0)
cadjustgrp3 <- c(0,0,-1,1)

cadjustgrpmat <- cbind(cadjustgrp1,cadjustgrp2,cadjustgrp3)
# contrasts(adjustgrp) <- cadjustgrpmat  # if orthogonal

# since they're not orthogonal

L <- matrix(c(1,1,1,1,-1,1,0,0,0,-1,1,0,0,0,-1,1),
		ncol = 4)

LInv <- solve(t(L))
Nonorth.Contrasts <- LInv[,2:4]
contrasts(adjustgrp) <- Nonorth.Contrasts

q3modelcontrasts1 <- lm(satis ~ agegrp*adjustgrp)
summary(q3modelcontrasts1, 
   split=list(adjustgrp=list("grp 1 vs 2"=1, "grp 2 vs 3"=2,
      "grp 3 vs 4"=3)))

# multiple comparison procedure - just look at adjustgrp
# notice that R gives interaction pairwise also
TukeyHSD(aov(lm(satis ~ agegrp*adjustgrp)))

# another set of contrasts for main effects 
cadjustgrp1 <- c(-2,1,0,1)
cadjustgrp2 <- c(0,1,-2,1)
cadjustgrp3 <- c(0,-1,1,0)

# contrasts(adjustgrp) <- cadjustgrpmat  # if orthogonal

# since they're not orthogonal

L2 <- matrix(c(1,1,1,1,-2,1,0,1,0,1,-2,1,0,-1,1,0),
		ncol = 4)

L2Inv <- solve(t(L2))
Nonorth.Contrasts2 <- L2Inv[,2:4]
contrasts(adjustgrp) <- Nonorth.Contrasts2

q3modelcontrasts2 <- lm(satis ~ agegrp*adjustgrp)
summary(q3modelcontrasts2, 
   split=list(adjustgrp=list("grp 1 vs 2 and 4"=1, "grp 3 vs 2 and 4"=2,
      "grp 2 vs 3"=3)))




  
