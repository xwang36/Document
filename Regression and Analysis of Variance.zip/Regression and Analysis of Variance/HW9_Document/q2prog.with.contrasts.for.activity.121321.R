setwd("e:/EDUC767 fall 2020/Activity for 121620")
anovaq4 <- read.table("q2data.activity.121620.forR.dat", header=TRUE, na.strings=".")
names(anovaq4)

# simplify names
gender <- anovaq4$gender
readgrp <- anovaq4$readgrp
mathscor <- anovaq4$mathscor

gender <- as.factor(gender)
readgrp <- as.factor(readgrp)

# second two way ANOVA model 
q4model <- lm(mathscor ~ gender*readgrp)
summary(q4model)
# TYPE I SS
anova(q4model)
# Type III SS
options(contrasts = c("contr.sum","contr.poly"))
q4model <- lm(mathscor ~ gender*readgrp)
summary(q4model)
drop1(q4model, .~., test="F")


# another set of contrasts for main effects 
creadgrp1 <- c(0,0,-1,1)
creadgrp2 <- c(-1,-1,2,0)
creadgrp3 <- c(0,-1,1,0)
creadgrpmat <- cbind(creadgrp1,creadgrp2,creadgrp3)
creadgrpmat

# contrasts(readgrp) <- creadgrpmat  # if orthogonal

# since they're not orthogonal

L3 <- matrix(c(1,1,1,1,0,0,-1,1,-1,-1,2,0,-1,1,0,0),
		ncol = 4)

L3Inv <- solve(t(L3))
Nonorth.Contrasts3 <- L3Inv[,2:4]
contrasts(readgrp) <- Nonorth.Contrasts3


cgender1 <- c(-1,1)
contrasts(gender) <- cgender1  # since there are only 2 levels not necessary
                               # but doesn't hurt
 
modelcontrasts3 <- lm(mathscor ~ gender*readgrp)
summary(modelcontrasts3, 
   split=list(gender=list("1 vs 2"=1),
   readgrp=list("readgrp 3 vs 4"=1, "readgrp 1 and 2 vs 3"=2,
     "readgrp 2 vs 3"=3)))

