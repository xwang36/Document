demoCorrMat <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                        0.19364,  1.00000,  0.04986,  0.07207,
                        0.31190,  0.04986,  1.00000,  0.61376,
                        0.31320,  0.07207,  0.61376,  1.00000), 
                          nrow=4, ncol=4)
demoCorrMat

XTX <- demoCorrMat[2:4,2:4]
XTX

XTY <- demoCorrMat[1,2:4]
XTY

regWeights <- solve(XTX)%*%XTY
regWeights

# in SAS 
#   beta = INV(XTX)*(XTY)   
# in R the solve() function takes the inverse
# watch what happens when you change some of the correlations


R32 <- 0 
R42 <- 0 
R43 <- 0   

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                              nrow=4, ncol=4)
demoCorrMatPlay

XTX <- demoCorrMatPlay[2:4,2:4]
XTX

XTY <- demoCorrMatPlay[1,2:4]
XTY

regWeights <- solve(XTX)%*%XTY
regWeights


# pick values for the correlations - you can change these

R32 <- .1
R42 <- .1
R43 <- .1

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                              nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)

XTY <- demoCorrMatPlay[1,2:4]
XTY

# beta = INV(XTX)*(XTY)   the solve() function takes the inverse

regWeights <- solve(XTX)%*%XTY
regWeights



