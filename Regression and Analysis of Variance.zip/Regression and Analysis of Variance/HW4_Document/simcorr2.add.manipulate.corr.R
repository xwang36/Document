# add manipulate
require(manipulate)

mu <- c(0,0)
stddev <- c(1,1)

corMat <- matrix(c(1, 0.78,
                   0.78, 1),ncol = 2)
corMat

covMat <- stddev %*% t(stddev) * corMat
covMat

set.seed(1)
library(MASS)
dat1 <- mvrnorm(n = 50, mu = mu, Sigma = covMat, empirical = FALSE)
#dat1 <- mvrnorm(n = 50, mu = mu, Sigma = covMat, empirical = TRUE)
dat1

colMeans(dat1)

cor(dat1)

r <- .5
n <- 50

require(MASS)
require(manipulate)
# manipulate plot for correlation
manipulate( {
 datasetmvnorm <- mvrnorm(n = n, mu = c(0,0), Sigma = matrix(c(1,r,r,1),2,2), 
    empirical = FALSE)
 plot(datasetmvnorm[,1],datasetmvnorm[,2],xlab="x", ylab="y", 
    xlim=c(-3.1,3.1), ylim=c(-3.1,3.1))
}
, n = slider(5,100, step=1)
, r = slider(0.0,1.0, step=.1)
)


# manipulate plot for covariance
manipulate( {
 datasetmvnorm <- mvrnorm(n = n, mu = c(0,0), 
    Sigma = matrix(c(var1,cov21,cov21,var2),2,2), 
    empirical = FALSE)
 correl <- cov21/(sqrt(var1)*sqrt(var2))
 correl
 scaleaxis <- 3.1*max(sqrt(var1),sqrt(var2))
 plot(datasetmvnorm[,1],datasetmvnorm[,2], 
   xlab="X variable", ylab="Y variable",
   xlim=c(-scaleaxis,scaleaxis), ylim=c(-scaleaxis,scaleaxis),
   main=c("Scatterplot for a Correlation of ", correl))  
}
, n = slider(5,100, step=1)
, var1 = slider(1,25, step=1)
, var2 = slider(1,25, step=1)
, cov21 = slider(0,25, step=.1)
)


# manipulate plot for covariance with ellipse
require(car)
manipulate( {
 datasetmvnorm <- mvrnorm(n = n, mu = c(0,0), 
    Sigma = matrix(c(var1,cov21,cov21,var2),2,2), 
    empirical = FALSE)
 correl <- cov21/(sqrt(var1)*sqrt(var2))
 correl
 scaleaxis <- 3.1*max(sqrt(var1),sqrt(var2))
 scatterplot(datasetmvnorm[,1],datasetmvnorm[,2], 
   xlab="X variable", ylab="Y variable",
   xlim=c(-scaleaxis,scaleaxis), ylim=c(-scaleaxis,scaleaxis),
   main=c("Scatterplot for a Correlation of ", correl), smooth=FALSE,
   ellipse=TRUE, pch=19)
}
, n = slider(5,100, step=1)
, var1 = slider(1,25, step=1)
, var2 = slider(1,25, step=1)
, cov21 = slider(0,25, step=.1)
)




