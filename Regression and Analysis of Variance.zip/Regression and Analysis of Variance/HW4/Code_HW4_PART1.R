demoCorrMat <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                        0.19364,  1.00000,  0.04986,  0.07207,
                        0.31190,  0.04986,  1.00000,  0.61376,
                        0.31320,  0.07207,  0.61376,  1.00000), 
                          nrow=4, ncol=4)

demoCorrMat
XTX <- demoCorrMat[2:4,2:4]
XTX
XTY <- demoCorrMat[1,2:4]
XTY

regWeights <- solve(XTX)%*%XTY
regWeights


R32 <- 0 
R42 <- 0 
R43 <- 0   

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                              nrow=4, ncol=4)
demoCorrMatPlay
XTX <- demoCorrMatPlay[2:4,2:4]
XTX
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights

# What are the regression coefficients now? 
###### the regression coefficients now are 0.194,0.312 and 0.313 ######

# How do they relate to the correlations between each predictor and the dependent variable?
###### With each predictor and the dependent variable increased, the correlations will be larger #######

R32 <- .1
R42 <- .1
R43 <- .1

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                              nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights



R32 <- .2
R42 <- .2
R43 <- .2

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                          nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights



R32 <- .3
R42 <- .3
R43 <- .3

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                          nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights



R32 <- .4
R42 <- .4
R43 <- .4

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                          nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights


R32 <- .5
R42 <- .5
R43 <- .5

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                          nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights



R32 <- .9
R42 <- .9
R43 <- .9

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                          nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights


R32 <- .999
R42 <- .999
R43 <- .999

demoCorrMatPlay <- matrix(c(1.00000,  0.19364,  0.31190,  0.31320,
                            0.19364,  1.00000,      R32,      R42,
                            0.31190,      R32,  1.00000,      R43,
                            0.31320,      R42,      R43,  1.00000), 
                          nrow=4, ncol=4)

XTX <- demoCorrMatPlay[2:4,2:4]
XTX
det(XTX)
XTY <- demoCorrMatPlay[1,2:4]
XTY
regWeights <- solve(XTX)%*%XTY
regWeights
