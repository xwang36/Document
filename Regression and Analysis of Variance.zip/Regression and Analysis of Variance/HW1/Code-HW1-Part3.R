# here are the data in a comma separated value file
Bordeaux <- read.csv("/Users/sky/desktop/Bordeaux.csv", header=TRUE)

# check the file
head(Bordeaux)  

# find out the variable names
names(Bordeaux) 

# set some graphing parameters
par(mfrow=c(1,2),oma = c(0, 0, 2, 0))

# plot the two subsets
plot(Bordeaux$ParkerPoints,Bordeaux$Price, xlab="Parker Points", 
   ylab="Price")
BordeauxReg <- lm(Price ~ ParkerPoints, data=Bordeaux) 
BordeauxReg 
abline(coef(BordeauxReg))

plot(Bordeaux$CoatesPoints,Bordeaux$Price, xlab="Coates Points", 
     ylab="")
BordeauxReg2 <- lm(Price ~ CoatesPoints, data=Bordeaux) 
BordeauxReg2 
abline(coef(BordeauxReg2))

# add a main title
mtext("Who is better?", outer=TRUE, cex=1.5)  
