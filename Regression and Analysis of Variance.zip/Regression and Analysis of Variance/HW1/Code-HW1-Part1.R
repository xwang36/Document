# read in the data
hibbs <- read.table("/Users/sky/desktop/hibbs.dat", header=TRUE)
hibbs

#create boxplots, histograms, and density plots for growth
par(mfrow=c(1,3))
boxplot(hibbs$growth)
hist(hibbs$growth)
plot(density(hibbs$growth))

#create boxplots, histograms, and density plots for vote
par(mfrow=c(1,4))
boxplot(hibbs$vote)
hist(hibbs$vote)
plot(density(hibbs$vote))

# generate some descriptive statistics
require("psych")
describe(hibbs[,2:3])

#or 
hibbsvars <- cbind(hibbs$growth,hibbs$vote)	
describe(hibbsvars)

# plot points
plot(hibbs$growth,hibbs$vote, xlab="Average recent growth in personal income",
     ylab="Incumbent party's vote share", 
     main = "Election Economics Prediction")  

# add labels to points
with(hibbs, text(hibbs$growth,hibbs$vote, 
                 labels = hibbs$year, pos= 4))            

# get the regression coefficients
hibbsReg <- lm(vote ~ growth, data=hibbs) 
hibbsReg

# add regression line
abline(coef(hibbsReg))                      

# plot the data without 1952
# I create a second data frame where I delete the first line
hibbs2 <- hibbs[2:16,]    

# plot points
plot(hibbs2$growth,hibbs2$vote, xlab="Average recent growth in personal income",
     ylab="Incumbent party's vote share", 
     main = "Election Economics Prediction")  

# add labels to points
with(hibbs2, text(hibbs2$growth,hibbs2$vote, 
                  labels = hibbs2$year, pos= 4))            

# get the regression coefficients
hibbs2Reg <- lm(vote ~ growth, data=hibbs2)  
hibbs2Reg

# add regression line
abline(coef(hibbs2Reg))                    




         



