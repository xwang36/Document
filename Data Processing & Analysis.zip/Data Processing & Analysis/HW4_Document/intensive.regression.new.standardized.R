# set working directory
setwd("e:/EDUC625 fall 2021")
# check what is the working directory
getwd()

# draw 100 values from a random uniform distribution

rvary <- runif(100)       # change to increase number of draws
hist(rvary)


# take the distribution [0,1] and stretch to [-1,1] 

# center the numbers

rvarycen <- rvary-mean(rvary)
hist(rvarycen)   # what does this look like
summary(rvarycen)

# multiply by 2

rvarystretch <- 2*rvarycen
hist(rvarystretch)
rvarystretch
summary(rvarystretch)

# calculate adjustment 

min(rvarystretch)
max(rvarystretch)
min(rvarystretch)+max(rvarystretch)

# adjustval makes the absolute value of minimum and maximum the same

adjustval = (min(rvarystretch)+max(rvarystretch))/2
adjustval

rvarystretch <- rvarystretch-adjustval
rvarystretch 

# divide by the maximum to make the range -1 to +1

summary(rvarystretch)
divisor <- max(rvarystretch)
divisor
rvarystretch <- rvarystretch/divisor
rvarystretch
summary(rvarystretch)

# fortunately R creates a random uniform distribution for any boundaries
#  this variable will not necessarily include -1 and 1
#  but for a large number of values it will get close enough

rvaryMinus1to1 <- runif(100, min=-1, max=1)
rvaryMinus1to1

# look at the range of rvaryMinus1to1

summary(rvaryMinus1to1) 

# get some data

potroy.widedata <- read.table("potroy.dat",header=TRUE)
potroy.widedata         # print out the whole data set
names(potroy.widedata)  # what are the variable names
head(potroy.widedata)   # the first 6 cases
tail(potroy.widedata)   # the last 6 cases
attributes(potroy.widedata)  # variable names, class, rownames
is.data.frame(potroy.widedata)  # is it a data frame
is.matrix(potroy.widedata)      # is it a matrix

# let's see what a sample value of rvarystretch looks like

rvarystretch     # to look at, don't include for general program
rvarystretch[1]

# z-score the variables since we are going to estimate a standardized regression

# check the original mean and standard deviation

mean(potroy.widedata$dep1)
sd(potroy.widedata$dep1)

# z-score dep1

dep1z <- (potroy.widedata$dep1-mean(potroy.widedata$dep1))/sd(potroy.widedata$dep1)

# check the z-score mean and standard deviation

mean(dep1z)
sd(dep1z)

# we could also use the scale() function
#dep1z <- scale(dep1)

# z-score dep2

dep2z <- (potroy.widedata$dep2-mean(potroy.widedata$dep2))/sd(potroy.widedata$dep2)

# check the z-score mean and standard deviation

mean(dep2z)
sd(dep2z)

# initialize sumsqerr which is a vector containing all tries
#  as does not exist
# initializing is necessary whenever you use [] to identify a vector or matrix
#  value

sumsqerr <- NULL   

# try a couple (don't include for general program)

  rvarystretch[1]
  dep2zhat <- rvarystretch[1]*dep1z
  dep2zerr <- dep2z - dep2zhat
  dep2zerrsq <- dep2zerr**2
  sumsqerr[1] <- sum(dep2zerrsq)
  sumsqerr[1] 

  rvarystretch[2]
  dep2zhat <- rvarystretch[2]*dep1z
  dep2zerr <- dep2z - dep2zhat
  dep2zerrsq <- dep2zerr**2
  sumsqerr[2] <- sum(dep2zerrsq)
  sumsqerr[2] 

  rvarystretch[3]
  dep2zhat <- rvarystretch[3]*dep1z
  dep2zerr <- dep2z - dep2zhat
  dep2zerrsq <- dep2zerr**2
  sumsqerr[3] <- sum(dep2zerrsq)
  sumsqerr[3] 

  sumsqerr

# now put rvarystretch in a loop

   sumsqerr <- NULL     # reinitializing is a good idea

   for (i in 1:100) {
    dep2zhat <- rvarystretch[i]*dep1z
    dep2zerr <- dep2z - dep2zhat
    dep2zerrsq <- dep2zerr**2
    sumsqerr[i] <- sum(dep2zerrsq)
    sumsqerr[i] 
  }

   sumsqerr            # all of the sums of squared errors
   min(sumsqerr)       # the minimum value
   minsumsqerr <- min(sumsqerr)

# now find out which one

   index <- NULL          # need to initialize the index

   for (i in 1:100) {
    if (sumsqerr[i] == minsumsqerr) index <- i
}
  
    index                 # this is the index
    rvarystretch[index]   # this is the slope

# check against lm() results

potroyreg2 <- lm(dep2z ~ dep1z)     # standardized regression
summary(potroyreg2)



