cowdata <- read.table("/Users/sky/desktop/Cowdata.forR.dat",header=TRUE)
cowdata

names(cowdata)  
head(cowdata)
tail(cowdata)

cowdata$logwt1

cowid <- cowdata$cowid
grp <- cowdata$grp
logwt1 <- cowdata$logwt1
logwt2 <- cowdata$logwt2
logwt3 <- cowdata$logwt3
logwt4 <- cowdata$logwt4
logwt5 <- cowdata$logwt5

cowmatrix <- cbind(logwt1,logwt2,logwt3,logwt4,logwt5)
cowmatrix

length(cowdata$logwt1)
length(logwt1)

cowdata_ave <- (logwt1 + logwt2 + logwt3 + logwt4 + logwt5)/5
cowdata_ave

cowdata_dif21 <- (logwt2 - logwt1)
cowdata_dif21

cowdata_dif32 <- (logwt3 - logwt2)
cowdata_dif32

cowdata_dif43 <- (logwt4 - logwt3)
cowdata_dif43

cowdata_dif54 <- (logwt5 - logwt4)
cowdata_dif54

cowmatrix_avedif <- cbind(cowdata_ave,cowdata_dif21,cowdata_dif32,cowdata_dif43,cowdata_dif54)
cowmatrix_avedif

#Get the Package "psych"
install.packages("psych", dependencies=TRUE)

require(psych)

describe(cowmatrix)

cor(cowmatrix)

describe(cowmatrix_avedif)

cor(cowmatrix_avedif)

corr.test(cowmatrix)
print(corr.test(cowmatrix), digits=6)
