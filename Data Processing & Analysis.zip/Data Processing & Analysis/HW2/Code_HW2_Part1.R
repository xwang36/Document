# 1a
addup_number<- 0 
for (s in 1:100) {
   addup_number<- addup_number+s }
   addup_number

# 1b
countk <- function(x) {
     k <- 0 
     for (i in x) {
       if (i %% 2 == 1|i %% 2 == 0) k<-k+i
     }
     return(k)
}
# Use the function on [1:100]
m<- 1:100
countk(m)
# One additional k=200
n<- 1:200 
countk(n)
# Two additional k=300
l<- 1:300 
countk(l)

#1c
f <- function(k) 
{return((k+1)*k/2) }
f(100)
f(200)
f(300)
