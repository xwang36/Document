# read in the data
potroy<- read.table("/Users/sky/desktop/potroy.dat", header=TRUE)
potroy

dep1<-potroy$dep1
dep1

# calculate n
n <- length(dep1)
n

# calculate mean
mean <- sum(dep1)/n
mean

dep1cen <- dep1-mean
dep1cen

# calculate variance
variance <- sum(dep1cen^2)/(n-1)
variance

# calculate standard deviation
standard_dev <- sqrt(variance)
standard_dev

# calculate skewness
skewness1 <- sum((dep1cen/standard_dev)^3)/n
skewness1

# calculate kurtosis
kurtosis1 <- sum((dep1cen/standard_dev)^4)/n-3
kurtosis1

# calculate skewness (with bias correction)
skewness2 <- sum((dep1cen/standard_dev)^3)*n/((n-1)*(n-2))
skewness2

# calculate kurtosis (with bias correction)
kurtosis2 <- sum((dep1cen/standard_dev)^4)*n*(n+1)/((n-1)*(n-2)*(n-3))-3
kurtosis2

# describe() function
require("psych")
describe(dep1)

# the skew and kurtosis of describe()function are equal to the skewness1 and kurtosis1
# the describe() use the version of the skewness and kurtosis without bias correction




