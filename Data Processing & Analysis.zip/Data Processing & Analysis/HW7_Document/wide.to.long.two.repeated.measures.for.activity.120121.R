setwd("e:/EDUC625 fall 2021/activity for 120121")
require("readxl")
require("stats")   #  for reshape

trendan1dat <- read_excel("trendan1.xlsx")

names(trendan1dat)
attributes(trendan1dat)
head(trendan1dat)
tail(trendan1dat)
trendan1dat <- as.data.frame(trendan1dat)


# write as long data set with time and whichvar
# wide to long using the reshape function to create new variables
# time0 and dep equivalent to the SAS output statement
# select subset of variables

trendan1_df <- trendan1dat[,c("id","famenv1","famenv2","famenv3","conf1",
 "conf2","conf3")]
trendan1_df

require("reshape")
melt(trendan1_df, id=c("id"),
    measure.vars=c("famenv1","famenv2","famenv3",
                   "conf1","conf2","conf3"))
trendan1_df_long <- melt(trendan1_df, id=c("id"),
    measure.vars=c("famenv1","famenv2","famenv3",
                   "conf1","conf2","conf3"))

# grp is still numeric even though it is listed in id=c("id","grp")
is.numeric(madjdata_df_long$grp)

trendan1_df_long

trendan1_df_long.sort <- trendan1_df_long[order(trendan1_df_long$id),]
trendan1_df_long.sort[1:10,]
trendan1_df_long.sort

# long to wide using dcast()

require(reshape2)
dcast(trendan1_df_long.sort, id + grp ~ variable, value.var="value")




