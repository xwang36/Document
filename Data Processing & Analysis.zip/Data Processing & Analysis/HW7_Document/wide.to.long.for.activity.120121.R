setwd("e:/EDUC625 fall 2021/activity for 120121")
require("readxl")
require("stats")   #  for reshape

trendan1dat <- read_excel("trendan1.xlsx")

names(trendan1dat)
attributes(trendan1dat)
head(trendan1dat)
tail(trendan1dat)
trendan1dat <- as.data.frame(trendan1dat)

#reshape is a special function for repeated measurements

# note the order of the variables in varying statement

trendan1.long <- reshape(trendan1dat, 
  varying = c("conf1","famenv1","conf2","famenv2","conf3","famenv3"), 
  v.names = c("conf","famenv"),
  timevar = "time0", 
  times = c(0:2), 
  new.row.names = 1:477,
  direction = "long")

trendan1.long

# almost but data are stacked with all occasions for an individual adjacent

trendan1.long.sort <- trendan1.long[order(trendan1.long$id),]
trendan1.long.sort[1:10,]
trendan1.long.sort











