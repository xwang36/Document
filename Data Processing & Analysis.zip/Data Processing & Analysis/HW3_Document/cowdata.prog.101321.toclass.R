# setting a working directory
setwd("e:/EDUC625 fall 2021")
# check what is the working directory
getwd()
cowdata.widedata <- read.table("e:/EDUC625 fall 2021/cowdata.forR.dat",header=TRUE)
cowdata.widedata
names(cowdata.widedata)  # what are the variable names
head(cowdata.widedata)   # the first 6 cases
tail(cowdata.widedata)   # the last 6 cases
attributes(cowdata.widedata)  # variable names, class, rownames

# give variables a simpler name

logwt1 <- cowdata.widedata$logwt1   
logwt2 <- cowdata.widedata$logwt2  
logwt3 <- cowdata.widedata$logwt3  
logwt4 <- cowdata.widedata$logwt4 
logwt5 <- cowdata.widedata$logwt5    


