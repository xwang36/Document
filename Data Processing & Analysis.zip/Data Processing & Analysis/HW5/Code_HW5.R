numstring <- c(1, 2, 1, 3, 2, 6, 2, 3, 1, 2, 5, 3, 2, 4, 
               8, 3, 2, 3, 3, 2, 1, 4, 6, 3, 2, 3, 
               2, 4, 2, 3, 1, 2, 3, 3, 2, 2, 2)

smoothedstring <- function(x) {
  a <- 0
  for (i in 1:length(x)) {
    k<- (x[i]+x[i+1]+x[i+2])/3
    a[i]<-k
    if (i == length(x)-2) break
  }
  return(a)
}
smoothed_string <- c(smoothedstring(numstring))
smoothed_string

plot(numstring, type="l",ylim=c(1,8),lty=1, lwd=2)
lines(smoothed_string,type="l",ylim=c(1,8),lty=1, col="blue" )  


numstring <- c(1, 2, 1, 3, 2, 6, 2, 3, 1, 2, 5, 3, 2, 4, 
               8, 3, 2, 3, 3, 2, 1, 4, 6, 3, 2, 3, 
               2, 4, 2, 3, 1, 2, 3, 3, 2, 2, 2)

smoothedstring2 <- function(x) {
  a <- 0
  for (i in 1:length(x)) {
    k<- (x[i]+x[i+1]+x[i+2]+x[i+3]+x[i+4])/5
    a[i]<-k
    if (i == length(x)-4) break
  }
  return(a)
}
smoothed_string2 <- c(smoothedstring2(numstring))
smoothed_string2

lines(smoothed_string2,type="l",ylim=c(1,8),lty=1, col="purple") 


# In terms of the three lines, what do you notice?
###### The three lines fluctuate in different extent
###### The original string fluctuates in the largest extent
###### The smoothed string moving average window of 3 fluctuates in the second-largest extent
###### The smoothed string moving average window of 3 fluctuates in the smallest extent