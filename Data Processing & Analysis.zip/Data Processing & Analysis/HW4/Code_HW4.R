# to draw separate random numbers for the slope
r<- runif(1000)    

rc <- r-mean(r)
summary(rc)

r_stretch <- 2*rc
summary(r_stretch)

min(r_stretch)
max(r_stretch)
min(r_stretch)+max(r_stretch)

adjust = (min(r_stretch)+max(r_stretch))/2
adjust

r_stretch <- r_stretch-adjust

summary(r_stretch)
divisor<- max(r_stretch)
divisor
r_stretch<- r_stretch/divisor
summary(r_stretch)


# read the data
potroy<- read.table("/Users/sky/desktop/potroy.dat", header=TRUE)
potroy

dep1=potroy$dep1
dep2=potroy$dep2


# to get the unstandardized regression slope range

b1_m <- sd(dep2)/sd(dep1)
b1_m
b1_r <- runif(1000, min = -1*b1_m, max = 1*b1_m)
summary(b1_r)

b0_min<- mean(dep2) - b1_m*mean(dep1)
b0_max <- mean(dep2) + b1_m*mean(dep1)
b0_r <- runif(1000, min = b0_min, max = b0_max)
summary(b0_r)


# to put b0 and b1 into a loop
sumsqerr <- NULL     
for (i in 1:1000) {
  dep2_h <- b0_r[i] + b1_r[i]*dep1
  dep2_er <- dep2 - dep2_h
  dep2_errsq <- dep2_er**2
  sumsqerr[i] <- sum(dep2_errsq)
  sumsqerr[i] 
}
min(sumsqerr)      
minsumsqerr <- min(sumsqerr)


# to get the slope and the intercept
index <- NULL            
for (i in 1:1000) {
  if (sumsqerr[i] == minsumsqerr) index <- i
}
index      
b0_r[index]    
b1_r[index]    


# check unstandardized regression
potroyreg1 <- lm(dep2 ~ dep1)
summary(potroyreg1)





