# Assignment 1
count_end_8 <- function(x) {
  
    k <- length(x)
  
    for(number_position in x){
      
    count_sum <- number_position*(number_position+1)/2
    if ( count_sum %% 10 == 8) 
    k <- c(k,number_position,count_sum)  
    }
    return(k)
  }

# Use the function on [1:100]
m<- 1:100
count_end_8(m)
# Use the function on [1:500]
n<- 1:500 
count_end_8(n)
# Use the function on [1:1000]
l<- 1:1000 
count_end_8(l)



# Assignment 2
innerProductCalc<-function(x,y) {
  k<-sum(x[,1]*x[,2])
  return(k)
}

c1 <- c(1,2,3,4,5,6,7,8,9,10)
c2 <- c(10,9,8,7,6,5,4,3,2,1)
cb <- cbind(c1,c2)
cb

innerProductCalc(cb)
 


# Assignment 3
# read the data
cowdata.widedata <- read.table("/Users/sky/desktop/Cowdata.forR.dat",header=TRUE)
cowdata.widedata

# give variables a simpler name
grp <- cowdata.widedata$grp
logwt1 <- cowdata.widedata$logwt1   
logwt2 <- cowdata.widedata$logwt2  
logwt3 <- cowdata.widedata$logwt3  
logwt4 <- cowdata.widedata$logwt4 
logwt5 <- cowdata.widedata$logwt5  

# #calculate the occasion means and standard deviations for all 16 cows
cowdata_matrix1 <- cbind(logwt1,logwt2,logwt3,logwt4,logwt5)
summary(cowdata_matrix1)
require("psych")
describe(cowdata_matrix1)

# to calculate the subgroup means and standard deviations for the healthy and ill subgroups
mean_group1 <- NULL
std_group1  <- NULL
for (i in 1:5) {
  mean_group1[i] <- mean(cowdata_matrix1[1:8,i])
  std_group1[i] <- sd(cowdata_matrix1[1:8,i])
}
mean_group1
std_group1 

mean_group2 <- NULL
std_group2 <- NULL
for (i in 1:5) {
  mean_group2[i] <- mean(cowdata_matrix1[9:16,i])
  std_group2[i] <- sd(cowdata_matrix1[9:16,i])
}
mean_group2
std_group2

cbind(mean_group1,mean_group2)
cbind(std_group1,std_group2)

# calculate average and differences
logwtave <- (logwt1 + logwt2 + logwt3 + logwt4 + logwt5)/5
logwt12dif <- logwt2-logwt1
logwt23dif <- logwt3-logwt2
logwt34dif <- logwt4-logwt3
logwt45dif <- logwt5-logwt4

# put into a matrix
cowdata_matrix2 <- cbind(grp,logwtave,logwt12dif,logwt23dif,logwt34dif,logwt45dif)
summary(cowdata_matrix2)
require("psych")
describe(cowdata_matrix2)

# to calculate the mean and standard deviations of the differences separately for the healthy and sick cows
mean_dif_group1 <- NULL
std_dif_group1 <- NULL
for (i in 3:6) {
  mean_dif_group1[i-2] <- mean(cowdata_matrix2[1:8,i])
  std_dif_group1[i-2] <- sd(cowdata_matrix2[1:8,i])
}
mean_dif_group1
std_dif_group1

mean_dif_group2 <- NULL
std_dif_group2 <- NULL
for (i in 3:6) {
  mean_dif_group2[i-2] <- mean(cowdata_matrix2[9:16,i])
  std_dif_group2[i-2] <- sd(cowdata_matrix2[9:16,i])
}
mean_dif_group2
std_dif_group2

cbind(mean_dif_group1,mean_dif_group2)
cbind(std_dif_group1,std_dif_group2)


# plot the subgroup means in a single plot using a line plot 
occasion <- c(1:5)
plot(occasion,mean_group1, type="o", pch=2, ylim=c(1.90,2.10))
points(occasion,mean_group2, type="o", pch=2)

occasion <- c(1:4)
plot(occasion,mean_dif_group1, type="o", pch=2, ylim=c(0.00,0.04))
points(occasion,mean_dif_group2, type="o", pch=2)



# Assignment 4

#  creates a random uniform distribution 
rvary_min1to1 <- runif(1000, min=-1, max=1)
summary(rvary_min1to1) 

# read the data
potroy<- read.table("/Users/sky/desktop/potroy.dat", header=TRUE)
potroy

dep1z=scale(potroy$dep1)
dep2z=scale(potroy$dep2)

# sum of squares
sumsqerr <- NULL

for (i in 1:1000) {
  dep2_zh <- rvary_min1to1[i]*dep1z
  dep2_ze <- dep2z - dep2_zh
  dep2_zeq <- dep2_ze**2
  sumsqerr[i] <- sum(dep2_zeq)
  sumsqerr[i] 
}

min(sumsqerr)
minsumsqerr <- min(sumsqerr)

#to determine which regression coefficient corresponds to that sum of squares
index <- NULL          
for (i in 1:1000) {
  if (sumsqerr[i] == minsumsqerr) index <- i
}
index                
rvary_min1to1[index]

# standardized regression
potroyreg2 <- lm(dep2z ~ dep1z)    
summary(potroyreg2)



