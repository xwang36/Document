# create the deck
cards <-
  as.character(outer(
    c(2:10, "J", "Q", "K", "A")
    , c("S", "H", "D", "C")
    , paste
    , sep = "_"
  ))
cards

# shuffle
deckThisHand <- sample(cards)
deckThisHand

# set the index to deal the top card:
currCardToDeal <- 1

# deal
nToDeal <- 7

# deal to player 1
player1 <- deckThisHand[currCardToDeal:(currCardToDeal+nToDeal-1)]
player1

currCardToDeal <- currCardToDeal+nToDeal

# deal to player 2
player2 <- deckThisHand[currCardToDeal:(currCardToDeal+nToDeal-1)]
player2

currCardToDeal <- currCardToDeal+nToDeal

# deal to player 3
player3 <- deckThisHand[currCardToDeal:(currCardToDeal+nToDeal-1)]
player3

currCardToDeal <- currCardToDeal+nToDeal

# etc

player <- matrix(NA, 3,7)

for(i in 1:7){
   for (j in 1:3) {
    k <- j + (i-1)*3
  player[j,i]<-deckThisHand[k]
 }
}

player

