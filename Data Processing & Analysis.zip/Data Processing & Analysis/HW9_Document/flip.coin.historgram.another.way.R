# Histogram of Doing 50 coin flips 1000 times

howManyHeads <-NULL 
for (j in 1:1000){
flip <- NULL              # initialize flip
flipvec <- NULL           # initialize flip vector
      # initialize count of how many heads
  for (i in 1:50) {                 # loop for multiple flips per replication
  ranunif <- runif(1,min=0,max=1)  # draw random numbers for each replication
  ranunif
  
  if(ranunif <=.5) flip="H"
  if(ranunif > .5) flip="T"
  
  flipvec[i] <- flip
  }
flipvec                      # vector of flips for 1 replication
table(flipvec)                   # table of replications
flipTable <- table(flipvec)      # number of heads
howManyHeads<- append(howManyHeads,flipTable[1])     # number of heads 
howManyHeads                  # number of heads
}
hist(howManyHeads )