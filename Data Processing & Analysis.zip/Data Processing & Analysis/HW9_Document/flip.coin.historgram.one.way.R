n <- 1000
k <- 50
heads <- NULL

flipCoin <- function(){
  flip <- runif(k, min = 0, max = 1)
  flip[flip < 0.5] <- 0
  flip[flip >= 0.5] <-1
  return(sum(flip))
}

for (i in 1:n){
  heads[i] <- flipCoin()
}

hist(heads, breaks = 0:k, main = paste('n = ', n, '; k =', k), )
hist(heads, breaks = 0:k, main = paste('n = ', n, '; k =', k), freq = F, ylim = c(0, 0.15))
lines(density(heads, bw=1), lwd=2, col="blue")

addnormx <- seq(min(heads), max(heads), length=length(heads))
addnormx
addnormy <- dnorm(addnormx,mean=mean(heads), sd=sd(heads))
lines(addnormx, addnormy, col="green", lwd=2)