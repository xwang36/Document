# change number of coin flips

flip <- NULL              # initialize flip
flipvec <- NULL           # initialize flip vector
howManyHeads <-NULL       # initialize count of how many heads

for (i in 1:5) {                 # loop for multiple flips per replication

ranunif <- runif(1,min=0,max=1)  # draw random numbers for each replication
ranunif

if(ranunif <=.5) flip="H"
if(ranunif > .5) flip="T"

flipvec[i] <- flip
}

flipvec                          # vector of flips for 1 replication

table(flipvec)                   # table of replications
flipTable <- table(flipvec)      # number of heads

howManyHeads <- flipTable[1]     # put the number of heads in a variable
 
howManyHeads                     # number of heads

# once you have the replications in a vector you can add the normal reference
# curve by adding the following to the probability histogram and density plot
addnormx <- seq(min(howManyHeads), max(howManyHeads), length=length(howManyHeads))
addnormx
addnormy <- dnorm(addnormx,mean=mean(howManyHeads), sd=sd(howManyHeads))
lines(addnormx, addnormy, col="green", lwd=2)
