#1a
va<-read.csv('/Users/sky/Desktop/HW2/vacation_logistic.csv')
va<-va[c(3:6)]

gender <- va$gender
age <- va$age
salary <- va$salary
travelled <- va$travelled

gender<-as.factor(gender)
travelled<-as.factor(travelled)

dim(va)
summary(va)

#1b

### The scatterplot between "travelled" and "gender" demonstrates that the possibility that the female will go on vacations is almost the same as the male. 
### The scatterplot between "travelled" and "age" demonstrates that older people are more likely to go on vacations than younger people.
### The scatterplot between "travelled" and "salary" demonstrates that consumers whose annual salary is larger than 70000$ or between 20000$-50000$ are more likerly to go on vacations than the others(below 20000$ or between 50000$-70000$). 

### The pairwise plot also verify and indicates : 1. gender will not influence the possibility whether people will go on vacations or not; 2. older people prefer to go on vacations than younger people; 3.Consumers whose annual salary is larger than 70000$ or between 20000$-50000$ are more likely to go on vacations than the others(below 20000$ or between 50000$-70000$).

plot(travelled ~ gender)
plot(travelled ~ age)
plot(travelled ~ salary)
dfc <- data.frame(travelled,gender,age,salary)
pairs(dfc)


#1c

set.seed(2022)
test<-sample(1:nrow(va), nrow(va)*0.1)

train_dat<-va[-test,]
test_dat<-va[test,] 
dim(train_dat)
dim(test_dat)


#1d

### Comment: The significant variables are "age" and "salary"
### The probability of a 25-year-old male with an annual salary of $50000 taking a vacation is 0.007484589
log1<-glm(travelled~gender+age+salary,data=train_dat,family='binomial')
summary(log1)


data_25_Male_50000_matrix <- data.frame(gender = "Male", age = 25, salary = 50000)
predict(log1,data_25_Male_50000_matrix,type = "response")

#1e

### The total number of misclassified observations on the TEST dataset is 19

predict_test<-predict(log1, test_dat[,-4], type='response')
table_1<-table(predict_test>=0.5,test_dat$travelled)
rownames(table_1)<-c("Not classified to Traverlers","Classified to Traverlers")
colnames(table_1)<-c("Non-Travelers","Travelers")
table_1

misclassification_1<-(table_1[1,2]+table_1[2,1])
misclassification_1
misclassification_1_rate<-(table_1[1,2]+table_1[2,1])/(table_1[1,2]+table_1[2,1]+table_1[1,1]+table_1[2,2])
misclassification_1_rate

#1f

### Comments: The misclassification rates in training data set is lower than that in testing data set, because misclassification_2_rate(0.1643991) < misclassification_1_rate(0.1938776)

data_predicted<-predict(log1,type="response") 
table_2<-table(data_predicted>=0.5,train_dat$travelled)
rownames(table_2)<-c("Not classified to Traverlers","Classified to Traverlers")
colnames(table_2)<-c("Non-Travelers","Travelers")
table_2

misclassification_2 <-(table_2[1,2]+table_2[2,1])
misclassification_2
misclassification_2_rate <-(table_2[1,2]+table_2[2,1])/(table_2[1,2]+table_2[2,1]+table_2[1,1]+table_2[2,2])
misclassification_2_rate

#1g

### False_positive_rate = FP/(FP+TN)
False_positive_rate <- table_1[2,1]/(table_1[2,1]+table_1[1,1])
False_positive_rate

### True_positive_rate = TP/(TP+FN)
True_positive_rate<- table_1[2,2]/(table_1[1,2]+table_1[2,2])
True_positive_rate

### False_negative_rate = FN/(TP+FN)
False_negative_rate<- table_1[1,2]/(table_1[1,2]+table_1[2,2])
False_negative_rate

### True_negative_rate = TN/(FP+TN)
True_negative_rate <- table_1[1,1]/(table_1[2,1]+table_1[1,1])
True_negative_rate 

#1h

### Comments: The ideal cutoff place should be around upper area of green line in this case and best probability should be 0.45

library(ROCR)
data_predicted_2<-predict(log1,type="response")
pred <- prediction(data_predicted_2, train_dat$travelled)
perf <- performance(pred, "tpr", "fpr")
plot(perf, colorize=TRUE)

#1i

### Yes, the misclassifications of using 0.45 as new cutoff is lower than using 0.5 as a cutoff.
### The misclassification rates for both the test & train dataset are different and the misclassification rates become lower when I use this using 0.45 as new cutoff.

predict_test<-predict(log1, test_dat[,-4], type='response')
table_3<-table(predict_test>=0.45,test_dat$travelled)
rownames(table_3)<-c("Not classified to Traverlers","Classified to Traverlers")
colnames(table_3)<-c("Non-Travelers","Travelers")
table_3

### misclassification_3(18) < misclassification_1(19)
misclassification_3<-(table_3[1,2]+table_3[2,1])
misclassification_3

### misclassification_3_rate(0.1836735) < misclassification_1_rate(0.1938776)
misclassification_3_rate<-(table_3[1,2]+table_3[2,1])/(table_3[1,2]+table_3[2,1]+table_3[1,1]+table_3[2,2])
misclassification_3_rate


data_predicted<-predict(log1,type="response") 
table_4<-table(data_predicted>=0.45,train_dat$travelled)
rownames(table_4)<-c("Not classified to Traverlers","Classified to Traverlers")
colnames(table_4)<-c("Non-Travelers","Travelers")
table_4

### misclassification_4(137) < misclassification_2(145)
misclassification_4 <-(table_4[1,2]+table_4[2,1])
misclassification_4

### misclassification_4_rate(0.1553288) < misclassification_2_rate(0.1643991)
misclassification_4_rate <-(table_4[1,2]+table_4[2,1])/(table_4[1,2]+table_4[2,1]+table_4[1,1]+table_4[2,2])
misclassification_4_rate




#2a
por<-read.csv('/Users/sky/Desktop/HW2/porcelain.csv')
por<-por[c(2:10)]
head(por)
dim(por)

#2b

names(por)[names(por) == "shatterResistance"] <- "strength"
colnames(por)
head(por)

#2c

strength<- por$strength

strengthlevel <- c()
for(i in 1:length(strength)) 
{if(strength[i]>30) 
{strengthlevel<-append(strengthlevel,1)} 
else
{strengthlevel<-append(strengthlevel,0)} 
}
strengthlevel

por <- cbind(por,strengthlevel)

#install.packages("plyr")
library(plyr)
count(por,"strengthlevel")


#2d
range_each_predictor <- c()
for(i in 1:ncol(por)) 
{if (i<=ncol(por)) 
{range_each_predictor <- append(range_each_predictor,range(por[i]))} 
}
range_each_predictor

range_each_predictor_matrix = matrix(
  range_each_predictor,
  nrow = 10,
  ncol = 2,
  byrow = TRUE
)
rownames(range_each_predictor_matrix) = c(colnames(por))
colnames(range_each_predictor_matrix) = c("min","max" )
range_each_predictor_matrix

#2e
sd_por <- sapply(por, sd)
sd_por
summary(por$kaolin)

#2f
summary(por$water)
por_delete_lowest25_water<- por[por$water>164.9,]
dim(por_delete_lowest25_water)

#2g
summary(por_delete_lowest25_water$kaolin)
furhter_por_delete_highest25_kaolin <- por_delete_lowest25_water[por_delete_lowest25_water$kaolin<331.0,]
por_new <- furhter_por_delete_highest25_kaolin
dim(por_new)

#2h
feldspar_new <- por_new$feldspar 
quartz_new <- por_new$quartz
ratio_feldspar_quartz <- feldspar_new/quartz_new
median(ratio_feldspar_quartz)

#2i
boneAsh_new<-por_new$boneAsh
containsboneash <-ifelse(boneAsh_new > 0,1,0)
por_new_column_containsboneash <- cbind(por_new,containsboneash)

#install.packages("plyr")
library(plyr)
count(por_new_column_containsboneash,"containsboneash")


#2j

# Comments:I print 7 times alert(“Old Porcelain Alert!!”)  

age_new <- por_new$age
z=0
for(i in 1:length(age_new)) 
{if (age_new[i]>=365)
{print("Old Porcelain Alert!!"); z=z+1 } 
}
print(z)


#3a

orange<-read.csv('/Users/sky/Desktop/HW2/orangejuice_lda.csv')

qualitylda<-c()
quality <- orange$quality
for(i in 1:length(quality)) 
{if (quality[i] < 6) 
{qualitylda <- append(qualitylda,1)} 
else if (quality[i]== 6) 
{qualitylda <- append(qualitylda,2)} 
else if(quality[i]> 6) 
{qualitylda <- append(qualitylda,3)} 
}

orange_new <- cbind(orange,qualitylda)
orange_new<-orange_new[c(1:10,12)]

orange_new$qualitylda<-as.factor(orange_new$qualitylda)

levels(orange_new$qualitylda)

#install.packages("plyr")
library(plyr)
count(orange_new,"qualitylda")

dim(orange_new)
head(orange_new,3)

#3b
set.seed(2020)
test<-sample(1:nrow(orange_new), nrow(orange_new)*0.2)
train_dat_1<-orange_new[-test,]
test_dat_1<-orange_new[test,] 
dim(train_dat_1)
dim(test_dat_1)


#3c
library(MASS)
lda.model <- lda(qualitylda~., data=train_dat_1)
lda.model
dev.off()
plot(lda.model)

### LDA: The total percent of misclassifications in the test dataset is 37%
lda_1 <- predict(lda.model, test_dat_1)
table(lda_1$class,test_dat_1$qualitylda) 
error_percent_1 = (28 + 4 + 43 + 10 + 26)/300
error_percent_1

### LDA The total percent of misclassifications in the train dataset is 36.25%
lda_2<-predict(lda.model)
table(lda_2$class,train_dat_1$qualitylda)
error_percent_2 = (118 + 6 + 175 + 51 + 12 + 73)/1200
error_percent_2

#3d

### Comments : The LDA model is better than the QDA model, because the total percent of misclassifications in LDA model on both train and test dataset are all lower than the QDA model.

qda.model <- qda(qualitylda~., data=train_dat_1)
qda.model

### QDA: The total percent of misclassifications in the test dataset is 43.33%
qda_1 <- predict(qda.model, test_dat_1)
table(qda_1$class,test_dat_1$qualitylda) 
error_percent_3 = (43 + 6 + 32 + 28 + 1 + 23)/300
error_percent_3 

### QDA: The total percent of misclassifications in the train dataset is 36.75%
qda_2<-predict(qda.model)
table(qda_2$class,train_dat_1$qualitylda)
error_percent_4 = (160 + 11 + 137 + 69 + 6 + 58)/1200
error_percent_4