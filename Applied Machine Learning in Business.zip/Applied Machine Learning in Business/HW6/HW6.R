#1 (1)
rm(list=ls())
uber<-read.csv('/Users/sky/Desktop/HW6/MadridUberData.csv')
dim(uber)

head(uber,3)
sum(is.na(uber))
uber <- na.omit(uber)
dim(uber)

uber_new<-uber[c(2:14)]
dim(uber_new)

#1 (2)
colnames(uber_new)[1] <- "CarDemand"
colnames(uber_new)

#1 (3)
uber_new$Seasons <- as.factor(uber_new$Seasons)
uber_new$Holiday <- as.factor(uber_new$Holiday)
uber_new$Functioning.Day <- as.factor(uber_new$Functioning.Day)

uber_new$Seasons <- as.numeric(uber_new$Seasons)
uber_new$Holiday <- as.numeric(uber_new$Holiday)
uber_new$Functioning.Day <- as.numeric(uber_new$Functioning.Day)

str(uber_new$Seasons)
str(uber_new$Holiday)
str(uber_new$Functioning.Day)

#1 (4)
set.seed(2022)
train <- sample(1:nrow(uber_new), 7446)
uber_new.train <- uber_new[train, ]
uber_new.test  <- uber_new[-train, ] 
nrow(uber_new[train, ])

#1a
log_1<- glm(CarDemand >700 ~., data = uber_new.train, family='binomial')

#1b
y_pred_1 <- predict(log_1, uber_new.test[,-1], type='response')

table_1 <- table(y_pred_1>=0.5, uber_new.test$CarDemand>700)
table_1

#1c
misclassification_rate_1 = (table_1[1,2]+table_1[2,1])/sum(table_1)
misclassification_rate_1



#2a
uber_dat<-uber_new[,-1]
str(uber_dat)

#2b
pr.out <- prcomp(uber_dat, scale = TRUE)

#2c
pr.var <- pr.out$sdev^2
pr.var

pve <- pr.var / sum(pr.var)
pve

cumsum(pve)

#2d
par(mfrow = c(1, 2))
plot(pve, xlab = "Principal Component", ylab = "Proportion of Variance Explained", ylim = c(0, 1), type = "b")
plot(cumsum(pve), xlab = "Principal Component", ylab = "Cumulative Proportion of Variance Explained",ylim = c(0, 1), type = "b")

#2e

# The minimum number of principal components is 8
n_PC <- 8

#2f
reduced_uber<-as.matrix(scale(uber_dat))%*%pr.out$rotation[,1:n_PC]
reduced_uber2<-cbind(CarDemand=uber_new$CarDemand,reduced_uber)
reduced_uber2<-as.data.frame(reduced_uber2)
head(reduced_uber2,2)
dim (reduced_uber2)

#2g
set.seed(2022)
train <- sample(1:nrow(uber_new), 7446)
reduced_uber2.train <- reduced_uber2[train, ]
reduced_uber2.test  <- reduced_uber2[-train, ]

t1 = Sys.time()
log_2<- glm(CarDemand > 700 ~., data = reduced_uber2.train, family='binomial')
t2 = Sys.time()
time_reduced_train_dataset = t2-t1
time_reduced_train_dataset 

#2h
y_pred_2 <- predict(log_2, reduced_uber2.test[,-1], type='response')

table_2  <- table(y_pred_2>=0.5, reduced_uber2.test$CarDemand>700)
table_2

#2i
misclassification_rate_2 = (table_2[1,2]+table_2[2,1])/sum(table_2)
misclassification_rate_2

#2j

t3 = Sys.time()
log_1<- glm(CarDemand > 700 ~., data = uber_new.train, family='binomial')
t4 = Sys.time()
time_full_train_dataset = t4-t3
time_full_train_dataset 

reduction_time_in_computation = time_full_train_dataset - time_reduced_train_dataset
reduction_time_in_computation



#3a
x <- scale(model.matrix(CarDemand ~ . - 1, data = uber_new))
dim(x)
y <- uber_new$CarDemand

#3b
n <- nrow(uber_new)
set.seed(2022)
ntest <- trunc(n*0.15)
testid <- sample(1:n, ntest)
nrow(x[testid, ])
nrow(uber_new[testid, ])

#3c
library(torch)
library(luz)

modnn <- nn_module(
  initialize = function() {
    self$hidden  <- nn_linear(12,20) 
    self$activation1 <- nn_relu() 
    self$hidden2 <- nn_linear(20,40) 
    self$activation2 <- nn_sigmoid() 
    self$hidden3 <- nn_linear(40,10) 
    self$activation3 <- nn_relu()
    self$output  <- nn_linear(10, 1) 
    
    self$dropout1 <- nn_dropout(0.25)
    self$dropout2 <- nn_dropout(0.25)
   
  },
  
  forward = function(x) {
    x %>% 
      self$hidden() %>% 
      self$activation1() %>%  
      self$dropout1() %>% 
      self$hidden2() %>% 
      self$activation2() %>% 
      self$dropout2() %>% 
      self$hidden3() %>%
      self$activation3() %>% 
      self$output() 
  }
)

#3d
modnn <- modnn %>%
  setup(
    loss = nn_l1_loss(),
    optimizer = optim_rmsprop, 
    metrics = list(luz_metric_mae()) )

#3e
torch_manual_seed(2022)
t5 = Sys.time()

fitted <- modnn %>% 
  fit(data = list(x[-testid, ], matrix(y[-testid], ncol = 1)),
    valid_data = list(x[testid, ], matrix(y[testid], ncol = 1)),
    epochs = 25)

t6 = Sys.time()
time_difference_fit = t6-t5
time_difference_fit

#3f
plot(fitted)

#3g
npred <- predict(fitted, x[testid, ]) 
MAE_NN<-sqrt(mean((y[testid] - npred)^2))
MAE_NN
as_array(MAE_NN)

#3h
Data_linear<-cbind(x,y)
Data_linear<-as.data.frame(Data_linear)

lm.fit <- lm(y ~., data = Data_linear[-testid, ])
lpred <- predict(lm.fit, Data_linear[testid, ])
MAE_linear <- with(Data_linear[testid, ], mean(abs(lpred - y)))
MAE_linear

#3i

# Linear Regression Model has a lower test mean absolute error (MAE_linear < MAE_NN).
# The reason is that compared with the Neural Net model, the Linear Regression model will fit the data in a line more simply and directly. 
# However, the Neural Net model will fit the data irregularly layer by layer, which will potentially increase more mean absolute error.

