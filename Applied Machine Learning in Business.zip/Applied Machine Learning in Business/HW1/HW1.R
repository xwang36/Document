### 1_a ###
mat.q4 = matrix(
  c(1,0,0,0,0, 
    1,1,0,0,0,
    1,5,6,0,0,
    1,3,4,9,0,
    1,3,6,4,8),
  nrow = 5,  
  ncol = 5,        
  byrow = TRUE         
)
rownames(mat.q4) = c("A","B","C","D","E" )
colnames(mat.q4) = c("Alpha","Beta","Gamma","Delta","Epsilon")

### 1_b ###
print(mat.q4)

### 1_c ###
mat.q4[c(2,5),c(2)]

### 1_d ###
my.list <- list(X = c(sample(x=100,size=100,replace=TRUE)), 
                B = matrix(data=rnorm(56),ncol=8),  
                ZETA = list(ALPHA = matrix(data = sample(x=10,size=49,replace=TRUE),ncol=7),  
                            BETA = matrix(data = rnorm(49),ncol=7)))

New_list<- my.list[[2]]
New_list[1:2,5:6]

names(my.list)[2] <- "Y"
my.list[2]      

### 2_a ###
vec1 <- c(19960217:20220908)

### 2_b ###

vec2 <- c()
num_100 <- seq(0,100)
for(i in length(num_100):1)
{if(num_100[i]%%7==0)
{vec2<-append(vec2,num_100[i])}
}
vec2

### 2_c ###

num_100_200<-rep(seq(100,200,2),times = seq(1,length(seq(100,200,2))))
num_100_200


### 2_d ###
alpha <- seq(200,1000,25)
beta  <- seq(600,280,-10)  
sum(alpha*beta)

### 3_a ###
### There are 506 rows and 13 columns in this dataset. The rows represent the predictor observations for a given suburb in Boston. The columns represent every predictor variable or measurement in 506 suburbs in Boston.

library(ISLR2)

Boston

?Boston

dim(Boston)

### 3_b ###
### Comments : Higher level of Medv(median value of owner-occupied homes in $1000s) may cause a lower crime rate (per capita crime rate by town),which demonstrates that crime rate (per capita crime rate by town) should be negatively correlated with Medv (median value of owner-occupied homes in $1000s). 
pairs(Boston)
plot(Boston$crim ~ Boston$medv)

### 3_c ###
### Comments: From the trend of the joint scatterplot, we can see higher level of rad (index of accessibility to radial highways),tax (full-value property-tax rate per $10,000), nox (nitrogen oxides concentration (parts per 10 million)), and indus (proportion of non-retail business acres per town) can cause higher crime rate (per capita crime rate by town).Thus, the above trend demonstrate that these variables(rad,tax,nox and indus) have a positive relationship with the crime rate (per capita crime rate by town).


?cor
B_Corr <- matrix(c(cor(Boston)),
                 nrow = 13,  
                 ncol = 13,        
                 byrow = TRUE         
)

rownames(B_Corr) = c("Crim","zn","indus","chas","nox","rm","age","dis","rad","tax","ptratio","lstat","medv" )
colnames(B_Corr) = c("Crim","zn","indus","chas","nox","rm","age","dis","rad","tax","ptratio","lstat","medv" )
B_Corr

B_Corr_Crim_Others = B_Corr[c(1), c(2:13)]
B_Corr_Crim_Others_Order = sort(B_Corr_Crim_Others,decreasing = T)
B_Corr_Crim_Others_Order 

?pairs
dfc <- data.frame(Boston$crim,Boston$rad,Boston$tax,Boston$nox,Boston$indus)
pairs(dfc)


### 3_d ###
###Some of the suburbs of Boston indeed appear to have particularly high crime rates and tax rates, but no suburbs seem to have particularly high pupil-teacher ratios. 

### Commetns: The median and mean of crime rate values are respectively 0.25651 and 3.61352 but the maxmium is 88.97620, so there are indeed some suburbs of Boston appear to have particularly high crime rates.If we give the cut off point(10), we can get the number of suburbs that appear to have particularly high crime rates is 54
hist(Boston$crim)
summary(Boston$crim)
Particular_High_Crim_rate <- subset(Boston, crim>10)
nrow(Particular_High_Crim_rate)

### Commetns: The median and mean of tax rates are respectively 330.0 and 408.2 but the maxmium is 711. From the histogram of Boston$ptratio, we can see the tax ratios of main suburbs concentrate on 200-450.Thus, there are indeed some suburbs of Boston appear to have particularly high tax rates. If we give the cut off point(666), we can get the number of suburbs that appear to have particularly high tax rate is 5
hist(Boston$tax)
summary(Boston$tax)
Particular_High_Tax_rate <- subset(Boston, tax>666)
nrow(Particular_High_Tax_rate)

### Commetns: The median and mean of pupil-teacher ratios are respectively 19.05 and 18.46. The maximum is only 22.00. From the histogram of Boston$ptratio, we can see the pupil-teacher ratios of most suburbs concentrate on 20-21.Thus, there should be not any suburbs of Boston appear to have particularly high Pupil-teacher ratios.
hist(Boston$ptratio)
summary(Boston$ptratio)


### 3_e ###
### There are 35 suburbs in this data set bound the Charles river. 

table(Boston$chas)


### 3_f ###
### The median pupil-teacher ratio is 19.05 among the towns in this data set.

summary(Boston$ptratio)

### 3_g ###
### The suburbs #399 and #406 with a median value of $5000 has lowest median value of owner-occupied homes.

### From the above graph, the other predicators values are:
###     crim	  zn	 indus	chas	nox	    rm	age	  dis	  rad	tax	ptratio	lstat
### 399	38.3518	0	    18.1	 0	 0.693	5.453	100	1.4896	24	666	  20.2	30.59
### 406	67.9208	0	    18.1	 0	 0.693	5.683	100	1.4254	24	666	  20.2	22.98

### Comments: The above results indicate that the crime rate (per capita crime rate by town) of suburbs #399 and #406  are 38.3518 and 67.9208, which is particularly higher than the mean crime rate (3.61352) in the whole Boston. The results shows that lowest median value of owner-occupied homes are very unsafe.

Sub_medv <- Boston[order(Boston$medv),]
Sub_medv[1,]
Sub_medv[2,]
Sub_medv[3,]
summary(Boston)

### 3_h ###

### There are 64 suburbs with more than 7 rooms per dwelling. There are 13 suburbs with more than 8 rooms per dwelling. 

### Comments: The above results indicate that these the mean crim(per capita crime rate by town) of 13 suburbs with more than 8 rooms per dwelling is 0.71879, which is lower than the mean crime rate (3.61352) in the whole Boston. However, the mean medv  (median value of owner-occupied homes in $1000s) in these 13 suburbs with more than 8 rooms per dwelling is 44.2, which is higher than the mean medv (22.53) in all 506 suburbs in Boston. Thus, the above evidence may demonstrate these 13 suburbs with more than 8 rooms per dwelling are more expensive, but also are relatively safe. 

Rm_over_seven <- subset(Boston, rm>7)
nrow(Rm_over_seven)

Rm_over_eight <- subset(Boston, rm>8)
nrow(Rm_over_eight)

Rm_over_eight
summary(Rm_over_eight)