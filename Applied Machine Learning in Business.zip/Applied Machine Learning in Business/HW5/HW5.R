#1a
rm(list=ls())
uber<-read.csv('/Users/sky/Desktop/HW5/MadridUberData.csv')
dim(uber)
head(uber,3)

#1b

# The 0 rows is removed
sum(is.na(uber))
uber <- na.omit(uber)
dim(uber)

#1c

# We verify that there is one less column in the data, because there are only 13 columns right now.
uber_new<-uber[c(2:14)]
dim(uber_new)

#1d
colnames(uber_new)[1] <- "CarDemand"
colnames(uber_new)

#1e
uber_new$Seasons <- as.factor(uber_new$Seasons)
uber_new$Holiday <- as.factor(uber_new$Holiday)
uber_new$Functioning.Day <- as.factor(uber_new$Functioning.Day)

str(uber_new$Seasons)
str(uber_new$Holiday)
str(uber_new$Functioning.Day)



#2a

# There are 7446 rows are in the train dataset
library(tree)
set.seed(2022)
train <- sample(1:nrow(uber_new), 7446)
uber_new.test <- uber_new[-train, ]
uber_new.testCarDemand <- uber_new[-train, "CarDemand"]
nrow(uber_new[train, ])

#2b
tree.uber_new <- tree(CarDemand ~ . , uber_new, subset = train)
tree.uber_new.pred <- predict(tree.uber_new, uber_new.test)
MSE_CarDemand = mean((tree.uber_new.pred - uber_new.testCarDemand )^2)
MSE_CarDemand

#2c
set.seed(2020)
cv.uber_new <- cv.tree(tree.uber_new)
plot(cv.uber_new$size, cv.uber_new$dev, type = "b")
abline(h=1100000000)

#2d
prune.Car <- prune.tree(tree.uber_new, best = 9)

#2e
plot(prune.Car)
text(prune.Car, pretty = 0)

#2f

# The percent increase in test in MSE as a result of this pruning compared to the full tree fit in 2b is 19.16147%
tree.uber_new.pred <- predict(prune.Car, uber_new.test)
MSE_prune.Car = mean((tree.uber_new.pred - uber_new.testCarDemand )^2)
MSE_prune.Car

increase_percent = (MSE_prune.Car - MSE_CarDemand)/MSE_CarDemand
increase_percent



#3a 

# The estimate of the bagging test error is 51550.46
library(randomForest)
set.seed(1)
bag.uber_new <- randomForest(CarDemand ~ ., data = uber_new, mtry = 12, importance = TRUE)
bag.uber_new 

#3b

# Hour, Temperature and Functioning.Day are the top 3 based on % Increase MSE
# Temperature, Hour and Solar.Radiation are the top 3 based on Percent Increase Node Purity

varImpPlot(bag.uber_new)

#3c

# The estimate of the bagging test error is 50873.89
set.seed(1)
rf.uber_new <- randomForest(CarDemand ~ .,  data = uber_new, mtry = 4, importance = TRUE)
rf.uber_new

#3d

# The estimate of the bagging test error is 49708.23 
set.seed(1)
rf.uber_new <- randomForest(CarDemand ~ .,  data = uber_new, mtry = 6, importance = TRUE)
rf.uber_new

#3e
Model <- c("Pruned", "Full", "Bag", "RF4", "RF6")

MSE_Bag = 51550.46
MSE_RF4 = 50873.89
MSE_RF6 = 49708.23

Test_MSE <- c(MSE_prune.Car, MSE_CarDemand, MSE_Bag, MSE_RF4, MSE_RF6)

plot(1:5, xaxt = "n", y= Test_MSE, type = "b", xlab = "Model", ylab = "Test MSE")
axis(1,at = 1:5, labels = Model)

#3f

# RF6 model has the lowest test MSE
# The percent decrease in test MSE for model compared to the pruned tree model is 67.52662%
decrease_Percent_RF6_Pruned = (MSE_RF6 - MSE_prune.Car)/MSE_prune.Car
decrease_Percent_RF6_Pruned



#4a
rm(list=ls())
mushroom<-read.csv('/Users/sky/Desktop/HW5/Mushroom.csv')
dim(mushroom)
head(mushroom,3)

#4b

# The 0 rows is removed
sum(is.na(mushroom))
mushroom<- na.omit(mushroom)
dim(mushroom)

#4c
table(mushroom$class)

#4d
mushroom$class<- as.factor(mushroom$class)

mushroom$cap.shape       <- as.factor(mushroom$cap.shape)
mushroom$cap.surface     <- as.factor(mushroom$cap.surface)
mushroom$cap.color       <- as.factor(mushroom$cap.color)
mushroom$does.bruise.or.bleed  <- as.factor(mushroom$does.bruise.or.bleed)
mushroom$gill.attachment <- as.factor(mushroom$gill.attachment)
mushroom$gill.spacing    <- as.factor(mushroom$gill.spacing)
mushroom$gill.color      <- as.factor(mushroom$gill.color)

mushroom$stem.root    <- as.factor(mushroom$stem.root)
mushroom$stem.surface <- as.factor(mushroom$stem.surface)
mushroom$stem.color   <- as.factor(mushroom$stem.color)
mushroom$veil.type    <- as.factor(mushroom$veil.type)
mushroom$veil.color   <- as.factor(mushroom$veil.color)
mushroom$has.ring     <- as.factor(mushroom$has.ring)
mushroom$ring.type    <- as.factor(mushroom$ring.type)
mushroom$spore.print.color   <- as.factor(mushroom$spore.print.color)
mushroom$habitat      <- as.factor(mushroom$habitat)
mushroom$season       <- as.factor(mushroom$season)

str(mushroom$class)

str(mushroom$cap.shape)      
str(mushroom$cap.surfac)   
str(mushroom$cap.color)      
str(mushroom$does.bruise.or.bleed)  
str(mushroom$gill.attachment)
str(mushroom$gill.spacing)   
str(mushroom$gill.color)    

str(mushroom$stem.root)    
str(mushroom$stem.surface) 
str(mushroom$stem.color)  
str(mushroom$veil.type)    
str(mushroom$veil.color)
str(mushroom$has.ring)    
str(mushroom$ring.type)    
str(mushroom$spore.print.color)   
str(mushroom$habitat)     
str(mushroom$season)   



#5a 

# The tree has 33 terminal nodes
# The training error is 0.08205
tree.mushroom <- tree(class ~ . , mushroom)
plot(tree.mushroom)
summary(tree.mushroom)

#5b
set.seed(2022)
train <- sample(1:nrow(mushroom), 0.8 * nrow(mushroom))
mushroom.train <- mushroom[train,  ]
mushroom.test  <- mushroom[-train, ]
nrow(mushroom.train)

#5c
tree.mushroom <- tree(class ~ ., mushroom, subset = train)
tree.pred_mushroom <- predict(tree.mushroom, mushroom.test,type = "class")
table_1 <- table(tree.pred_mushroom, mushroom.test$class)
table_1
misclassification_mushroom <-(table_1[1,2]+table_1[2,1])/(table_1[1,2]+table_1[2,1]+table_1[1,1]+table_1[2,2])
misclassification_mushroom

#5d
set.seed(2021)
cv.mushroom <- cv.tree(tree.mushroom, FUN = prune.misclass)
plot(cv.mushroom$size, cv.mushroom$dev, type = "b")
abline(h = 6000,lty = 3)

#5e

# The optimal tree size is 18
prune.mushroom <- prune.misclass(tree.mushroom, best = 18)

#5f
tree.pred_mushroom_prune <- predict(prune.mushroom, mushroom.test, type = "class")
table_2 <- table(tree.pred_mushroom_prune, mushroom.test$class)
table_2
misclassification_mushroom_prune <-(table_2[1,2]+table_2[2,1])/(table_2[1,2]+table_2[2,1]+table_2[1,1]+table_2[2,2])
misclassification_mushroom_prune

#5g
plot(prune.mushroom)



#6a

#The estimate of the bagging test error is 0.03% 
set.seed(2)
bag.mushroom <- randomForest(class ~ ., data = mushroom, mtry = 20, importance = TRUE)
bag.mushroom 

#6b

# cap.color, gill.color and stem.surface are the top 3 using the Accuracy indices as the criteria
# cap.surface, gill.attachment and cap.color are the top 3 using the Gini indices as the criteria
varImpPlot(bag.mushroom)

#6c

# The estimate of the test error is 0% 
set.seed(1)
rf.mushroom <- randomForest(class ~ ., data = mushroom, mtry = 5, importance = TRUE)
rf.mushroom

#6d

# cap.surface, gill.attachment and cap.color  are the top 3 using the Accuracy indices as the criteria
# cap.surface, gill.attachment and gill.color are the top 3 using the Gini indices as the criteria
varImpPlot(rf.mushroom)

#6e
test_error_rf.mushroom <- c()

for(i in 2:7)
{
set.seed(1)
rf.mushroom.i <- randomForest(class ~ ., data = mushroom, mtry = i, importance = TRUE)
mushroom_con_matrix <- rf.mushroom.i$confusion
test_er_mushroom = (mushroom_con_matrix[1,2] + mushroom_con_matrix[2,1])/sum(mushroom_con_matrix)
test_error_rf.mushroom <- append(test_error_rf.mushroom,test_er_mushroom)
}

#6f
plot(x = c(2,3,4,5,6,7), y= test_error_rf.mushroom, type = "b", xlab = "node", ylab = "misclassification rate")



#7a

library(e1071)
set.seed(2020)

classifier_mushroom_1 <- svm(formula = class ~ .,data = mushroom.train, type = 'C-classification', kernel = 'linear')
y_pred_mushroom_1     <- predict(classifier_mushroom_1, newdata = mushroom.test[,-1])

tabl_svm_mushroom_1   <- table(y_pred_mushroom_1,mushroom.test$class)
tabl_svm_mushroom_1

test_error_svm_mushroom_1 = (tabl_svm_mushroom_1[1,2]+tabl_svm_mushroom_1[2,1])/sum(tabl_svm_mushroom_1)
test_error_svm_mushroom_1

#7b

set.seed(2020)
classifier_mushroom_2 <- svm(class ~ ., data = mushroom.train, type = 'C-classification', kernel = 'linear', cost = 0.1)
y_pred_mushroom_2     <- predict(classifier_mushroom_2, newdata = mushroom.test[,-1])

tabl_svm_mushroom_2   <- table(y_pred_mushroom_2, mushroom.test$class)
tabl_svm_mushroom_2

test_error_svm_mushroom_2 = (tabl_svm_mushroom_2[1,2]+tabl_svm_mushroom_2[2,1])/sum(tabl_svm_mushroom_2)
test_error_svm_mushroom_2

#7c

set.seed(2020)
Radialsvm         <- svm(class ~ ., data = mushroom.train, kernel="radial", scale=F)
y_pred_mushroom_3 <- predict(Radialsvm, newdata = mushroom.test[,-1])

tabl_svm_mushroom_3 <- table(y_pred_mushroom_3,mushroom.test$class)
tabl_svm_mushroom_3

test_error_svm_mushroom_3 = (tabl_svm_mushroom_3[1,2]+tabl_svm_mushroom_3[2,1])/sum(tabl_svm_mushroom_3)
test_error_svm_mushroom_3

#7d
log_mushroom      <- glm(class ~., data = mushroom.train, family='binomial')
y_pred_mushroom_4 <- predict(log_mushroom, mushroom.test[,-1], type='response')

tabl_log_mushroom_4 <- table(y_pred_mushroom_4>=0.5, mushroom.test$class)
tabl_log_mushroom_4

test_error_log_mushroom_4 = (tabl_log_mushroom_4[1,2]+tabl_log_mushroom_4[2,1])/sum(tabl_log_mushroom_4)
test_error_log_mushroom_4

#7e
library(MASS)
lda.model    <- lda(class~., data = mushroom.train)
lda_mushroom <- predict(lda.model, mushroom.test)

tabl_lda_mushroom_5 <-table(lda_mushroom$class, mushroom.test$class)
tabl_lda_mushroom_5

test_error_lda_mushroom_5 = (tabl_lda_mushroom_5[1,2]+tabl_lda_mushroom_5[2,1])/sum(tabl_lda_mushroom_5)
test_error_lda_mushroom_5

#7f

# The Radial SVM default cost model gives the lowest test error misclassification rate, which is 0.003029311

#7g

# The best model here is not better than the best Random Forest, because the test error of the Random Forest test is lower than the test error of above model
# I would like to recommend using Random Forest test model for this dataset